FCKLang.EmbedMoviesBtn			  = 'Embed Movies';
FCKLang.EmbedMoviesDlgTitle		= 'Embed Movies';
FCKLang.EmbedMoviesDlgName		= 'Embed Movies';
FCKLang.EmbedMoviesTooltip	  = 'Insert a movie display inside your document.';
FCKLang.EmbedMoviesInfoTab	  = 'Info';
FCKLang.EmbedMoviesUploadTab  = 'Upload';
FCKLang.EmbedMoviesURL        = 'URL';
FCKLang.EmbedMoviesAlertUrl   = 'No movie URL specified.';
