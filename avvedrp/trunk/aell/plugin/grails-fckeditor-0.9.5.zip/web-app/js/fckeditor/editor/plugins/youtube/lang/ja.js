/*
 * For FCKeditor 2.3
 * 
 * 
 * File Name: ja.js
 * 	Japanese language file for the youtube plugin.
 * 
 * File Authors:
 * 		Uprush (uprushworld@yahoo.co.jp) 2007/10/30
 */

FCKLang['YouTubeTip']			= 'YouTube挿入/編集' ;
FCKLang['DlgYouTubeTitle']		= 'YouTubeプロパティ' ;
FCKLang['DlgYouTubeHelp']		= 'YouTube動画の埋め込みコードを貼り付けください。' ;
FCKLang['DlgYouTubeCode']		= '埋め込みコード' ;
FCKLang['DlgAlertYouTubeCode']	= '埋め込みコードを挿入してください。' ;
FCKLang['DlgAlertYouTubeSecurity']	= '埋め込みコードが正しくありません。' ;