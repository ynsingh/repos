package org.codehaus.groovy.grails.plugins.bubbling;

class Bubbling {

    static version = "1.5.0"
    
}
