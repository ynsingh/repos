Ant.property(environment:"env")
grailsHome = Ant.antProject.properties."env.GRAILS_HOME"

includeTargets << grailsScript("Init")
checkVersion()
configureProxy()

downloadDir = new File(grailsWorkDir, "download")
downloadPath = downloadDir.absolutePath

def version = "2-1"
Ant.sequential {
    mkdir(dir:"${downloadDir}")

    event("StatusUpdate", ["Downloading Bubbling Library 2.1"])

    get(dest:"${downloadPath}/bubbling.library.v${version}.zip",
        src:"http://github.com/caridy/bubbling-library-${version}-backup/zipball/v2-1",
        verbose:true,
        usetimestamp:true)
    unzip(dest:"${downloadPath}/bubbling.library.v${version}",
        src:"${downloadPath}/bubbling.library.v${version}.zip")	
	
    mkdir(dir:"${basedir}/web-app/js/yui-cms/${version}")
    copy(todir:"${basedir}/web-app/js/yui-cms/${version}") {
        fileset(dir:"${downloadPath}/bubbling.library.v${version}/caridy-bubbling-library-${version}-backup-dfd1fb5625582bc0236e0a0704bdfc7aa5ca846f/build", includes:"**/**")
    }		 
}            
event("StatusFinal", ["Bubbling Library ${version} installed successfully"])
