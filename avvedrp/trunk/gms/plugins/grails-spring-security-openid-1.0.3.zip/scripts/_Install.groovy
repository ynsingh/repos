println '''
*************************************************************
* You've installed the Spring Security OpenID plugin.       *
*                                                           *
* Next run the "s2-init-openid" script to configure OpenID. *
*                                                           *
*************************************************************
'''
